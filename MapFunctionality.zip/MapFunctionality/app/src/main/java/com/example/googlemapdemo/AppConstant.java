package com.example.googlemapdemo;

public class AppConstant {
    public static final String PREF_MIN = "Pref Min";
    public static final String PREF_MAX = "Pref Max";
    public static final String  ZOOM_TO = "Zoom_to";
    public static final String ZOOM_BY="Zoom_by";
    public static final String ZOOM_BY_POINT="Zoom_By_Point";
    public static final String LAT_LNG_PADDING = "lat_lng_padding";
    public static final String CENTERING = "CENTERING";
    public static final String BOUND_HEIGHT_WIDTH = "Bound_HEIGHT_WIDTH";
    public static final String MAP_AREA= "MAP_AREA";
}

