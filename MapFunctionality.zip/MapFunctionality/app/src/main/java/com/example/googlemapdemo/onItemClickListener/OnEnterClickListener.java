package com.example.googlemapdemo.onItemClickListener;

public interface OnEnterClickListener {

    void onEnterClick(String tag,String value);
}
